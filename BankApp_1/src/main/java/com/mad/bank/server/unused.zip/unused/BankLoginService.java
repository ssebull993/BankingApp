package com.mad.bank.server.unused;

import com.mad.bank.common.Communicative;
import com.mad.bank.common.Connectable;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class BankLoginService /*extends UnicastRemoteObject implements Connectable*/ {
    public static final String DRIVER = "org.sqlite.JDBC";
    public static final String DB_URL = "jdbc:sqlite:Bank.db";
    private Connection conn;
    private Statement stmt;
    private Map<String, String> idToPass = new HashMap();

    protected BankLoginService() throws RemoteException, ClassNotFoundException, SQLException {
        try {
            Class.forName(BankLoginService.DRIVER);
            conn = DriverManager.getConnection(DB_URL);
            stmt = conn.createStatement();
            conn.setAutoCommit(true);
            System.out.println("Opened database successfully");
            ResultSet rs = stmt.executeQuery( "SELECT userID, password FROM customer_info;" );
            idToPass = convertResultSetToMap(rs);
        } finally {
            stmt.close();
            conn.close();
        }
    }

    private Map<String,String> convertResultSetToMap(ResultSet rs) throws SQLException {
        Map<String,String> map = new HashMap();
        while (rs.next()) {
            map.put(rs.getString("userID"),rs.getString("password"));
        }
        return map;
    }

    //@Override
    public boolean login(String userId, String password, Communicative client) throws RemoteException {
        if(idToPass.containsKey(userId) && password.equals(idToPass.get(userId))) {
            client.messageClient("Logged in");
            return true;
        }else{
            return false;
        }
    }
}
