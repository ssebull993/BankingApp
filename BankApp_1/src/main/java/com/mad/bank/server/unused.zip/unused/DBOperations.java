package com.mad.bank.server.unused;

public class DBOperations {
}
