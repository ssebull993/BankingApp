package com.mad.bank.server.unused;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BankAccount implements Serializable {
    private final String accountID;
    private final String userID;
    private double balance;
    private ArrayList<BankAccount> bankAccounts;

    public BankAccount(String id, String userID, double value) {
        this.accountID = id;
        this.userID = userID;
        this.balance = value;
    }

    public String getBalance() {
        return Double.toString(this.balance);
        //return this.balance;
    }

    public synchronized void deposit(int val) {
        this.balance += val;
    }

    public synchronized void withdraw(int val) {
        if(this.balance >= val) { this.balance -= val; }
        else { sendMessage("Not enough funds!"); }
    }

    public String sendMessage(String message) {
        return message;
    }

    private ArrayList<BankAccount> getAccounts() {
        Connection conn = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:Bank.db");
            stmt = conn.createStatement();
            conn.setAutoCommit(true);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(conn != null && stmt != null) {
                    stmt.close();
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

}
