package com.mad.bank.server.unused;

import java.io.Serializable;

public class BankCustomer implements Serializable {
        private final String userId;
    private String firstName;
    private String lastName;
    private String address;
    private String password;
    private String totalBalance;

    public BankCustomer(String userId, String firstName, String lastName, String address, String password) {
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.password = password;
    }

    public String getUserId() { return userId; }
    public String getFirstName() { return this.firstName; }
    public String getLastName() { return this.lastName; }
    public String getAddress() { return this.address; }
    public String getPassword() { return this.password; }
}